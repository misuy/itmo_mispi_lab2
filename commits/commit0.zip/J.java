public interface J {

    String kk();

    java.lang.Class qq();
}
