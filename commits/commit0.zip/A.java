public class A implements J {

    private byte j = 1;

    private double d = 100.500;

    public float ff() {
        return 0;
    }

    public double ad() {
        return 12.12;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }
}
