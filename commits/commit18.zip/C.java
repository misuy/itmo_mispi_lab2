public class C extends A {

    private String b = "test";

    private long g = 1234;

    public byte oo() {
        return 1;
    }

    public Object pp() {
        return this;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public long ac() {
        return 222;
    }

    public int af() {
        return -1;
    }

    public void aa() {
        return;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public int cc() {
        return 42;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
