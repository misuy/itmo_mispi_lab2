public class A extends null implements J {

    private byte j = 1;

    private double d = 100.500;

    public float ff() {
        return 0;
    }

    public double ad() {
        return 12.12;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public int cc() {
        return 13;
    }
}
