public class A extends null implements J {

    private byte j = 1;

    private double d = 100.500;

    public float ff() {
        return 0;
    }

    public double ad() {
        return 12.12;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public double ee() {
        return 500.100;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public int af() {
        return -1;
    }

    public long dd() {
        return 33;
    }
}
