public class E extends null {

    double ee();

    String nn();
}
