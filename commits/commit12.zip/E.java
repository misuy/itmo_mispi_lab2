public interface E {

    double ee();

    String nn();
}
