public class C extends A {

    private String b = "test";

    private long g = 1234;

    public byte oo() {
        return 1;
    }

    public Object pp() {
        return this;
    }

    public long ac() {
        return 222;
    }

    public int ae() {
        return 8;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public int af() {
        return -1;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int cc() {
        return 13;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
