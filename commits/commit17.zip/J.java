public class J extends null {

    String kk();

    java.lang.Class qq();
}
