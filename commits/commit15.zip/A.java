public class A implements J {

    private byte j = 1;

    private double d = 100.500;

    public float ff() {
        return 0;
    }

    public double ad() {
        return 12.12;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public Object pp() {
        return this;
    }

    public long dd() {
        return 100500;
    }
}
