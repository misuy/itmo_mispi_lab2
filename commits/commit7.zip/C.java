public class C extends A {

    private String b = "test";

    private long g = 1234;

    public byte oo() {
        return 1;
    }

    public Object pp() {
        return this;
    }

    public long ac() {
        return 222;
    }
}
